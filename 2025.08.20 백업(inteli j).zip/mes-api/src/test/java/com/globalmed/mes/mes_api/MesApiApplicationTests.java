package com.globalmed.mes.mes_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
