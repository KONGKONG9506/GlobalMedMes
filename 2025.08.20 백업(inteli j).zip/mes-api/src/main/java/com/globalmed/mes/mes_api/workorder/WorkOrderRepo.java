package com.globalmed.mes.mes_api.workorder;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkOrderRepo extends JpaRepository<WorkOrderEntity, String> {
    Optional<WorkOrderEntity> findByWorkOrderNumber(String workOrderNumber);
}