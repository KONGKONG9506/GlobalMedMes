package com.globalmed.mes.mes_api.workorder;

import com.globalmed.mes.mes_api.common.PageResponse;
import com.globalmed.mes.mes_api.workorder.dto.WorkOrderListDto;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/work-orders")
@RequiredArgsConstructor
public class WorkOrderQueryController {

    private final WorkOrderRepo repo;

    // 충돌 방지: page/size 파라미터 있을 때만 리스트 매핑
    @GetMapping(params = {"page","size"})
    public ResponseEntity<PageResponse<WorkOrderListDto>> list(
            @RequestParam int page,
            @RequestParam int size,
            @RequestParam(defaultValue = "createdAt,desc") String sort) {

        String[] sp = sort.split(",");
        Sort s = (sp.length == 2 && "asc".equalsIgnoreCase(sp[1]))
                ? Sort.by(sp[0]).ascending()
                : Sort.by(sp[0]).descending();
        Pageable pageable = PageRequest.of(page, size, s);

        Page<WorkOrderEntity> result = repo.findAll(pageable);

        var dtoPage = result.map(wo -> new WorkOrderListDto(
                wo.getWorkOrderId(),
                wo.getWorkOrderNumber(),
                wo.getItemId(),
                wo.getProcessId(),
                wo.getEquipmentId(),
                wo.getOrderQty(),
                wo.getProducedQty(),
                (wo.getStatusCode() != null ? wo.getStatusCode().getCode() : null)
        ));

        return ResponseEntity.ok(PageResponse.of(dtoPage, sort));
    }

    // 상세 조회(선택)
    @GetMapping("/{id}")
    public ResponseEntity<WorkOrderListDto> get(@PathVariable String id){
        var wo = repo.findById(id).orElseThrow();
        var dto = new WorkOrderListDto(
                wo.getWorkOrderId(),
                wo.getWorkOrderNumber(),
                wo.getItemId(),
                wo.getProcessId(),
                wo.getEquipmentId(),
                wo.getOrderQty(),
                wo.getProducedQty(),
                (wo.getStatusCode() != null ? wo.getStatusCode().getCode() : null)
        );
        return ResponseEntity.ok(dto);
    }
}