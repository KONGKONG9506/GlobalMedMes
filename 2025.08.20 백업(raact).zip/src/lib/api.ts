import axios from "axios";
import { useAuthStore } from "../store/auth";
import { getErrorMessage } from "./error";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE ?? "http://localhost:8080",
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const status = err?.response?.status as number | undefined;
    if (status === 401) {
      useAuthStore.getState().logout();
    }
    // 로그만 찍고 표준 에러로 리젝
    console.warn("[API ERROR]", getErrorMessage(err));
    return Promise.reject(err);
  }
);

export type ErrorResponse = {
  code: string;
  message: string;
  details?: Record<string, unknown> | null;
  traceId?: string;
  timestamp?: string;
  path?: string;
  method?: string;
};

export type PageResponse<T> = {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  sort: string;
};