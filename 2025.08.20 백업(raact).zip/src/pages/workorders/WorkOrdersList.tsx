import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../../lib/api";
import { toPage } from "../../adapters/page";
import type { PageResponse } from "../../types/api";

type WorkOrderItem = {
  workOrderId: string;
  workOrderNumber: string;
  itemId: string;
  processId: string;
  equipmentId: string;
  orderQty: number;
  producedQty: number;
  status: string | null;
};

export default function WorkOrdersList() {
  const queryClient = useQueryClient();

  const [editingWorkOrderId, setEditingWorkOrderId] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const { data, isLoading, error } = useQuery({
    queryKey: ["work-orders", 0, 20, "createdAt,desc"],
    queryFn: async () => {
      const res = await api.get<PageResponse<WorkOrderItem>>("/work-orders", {
        params: { page: 0, size: 20, sort: "createdAt,desc" },
      });
      return toPage(res.data);
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ workOrderId, newStatus }: { workOrderId: string; newStatus: string }) => {
      await api.put(`/work-orders/${workOrderId}/status`, {
        toStatus: newStatus, // ✅ 필드명 수정됨
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["work-orders"] });
      setShowConfirmModal(false);
      setEditingWorkOrderId(null);
    },
    onError: (err: any) => {
      alert("상태 변경 실패: " + (err?.response?.data?.message || "오류 발생"));
      console.error(err);
    },
  });

  if (isLoading) return <div>로딩 중...</div>;
  if (error) return <div>에러 발생</div>;

  const statusOptions = ["P", "R", "C"]; // ✅ 전체 상태 목록

  function ConfirmModal() {
    if (!showConfirmModal || !editingWorkOrderId) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center">
        <div className="bg-white p-6 rounded shadow-lg">
          <p>상태를 "{selectedStatus}" 로 변경하시겠습니까?</p>
          <div className="mt-4 flex justify-end space-x-3">
            <button className="px-4 py-2 bg-gray-300 rounded" onClick={() => setShowConfirmModal(false)}>
              취소
            </button>
            <button
              className="px-4 py-2 bg-blue-600 text-white rounded"
              onClick={() =>
                updateStatusMutation.mutate({
                  workOrderId: editingWorkOrderId,
                  newStatus: selectedStatus,
                })
              }
            >
              확인
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-lg font-semibold mb-3">작업지시</h1>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 text-left">번호</th>
            <th className="p-2 text-left">품목</th>
            <th className="p-2 text-left">설비</th>
            <th className="p-2 text-right">지시</th>
            <th className="p-2 text-right">누적</th>
            <th className="p-2 text-left">상태</th>
            <th className="p-2 text-left">변경</th>
          </tr>
        </thead>
        <tbody>
          {data!.items.map((it) => (
            <tr key={it.workOrderId} className="border-t">
              <td className="p-2">{it.workOrderNumber}</td>
              <td className="p-2">{it.itemId}</td>
              <td className="p-2">{it.equipmentId}</td>
              <td className="p-2 text-right">{it.orderQty}</td>
              <td className="p-2 text-right">{it.producedQty}</td>
              <td className="p-2">{it.status ?? "-"}</td>
              <td className="p-2">
                {editingWorkOrderId === it.workOrderId ? (
                  <>
                    <select
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value)}
                      className="border rounded px-2 py-1"
                    >
                      <option value="">상태 선택</option>
                      {statusOptions.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <button
                      className="ml-2 px-2 py-1 bg-green-600 text-white rounded"
                      disabled={!selectedStatus}
                      onClick={() => setShowConfirmModal(true)}
                    >
                      변경
                    </button>
                    <button
                      className="ml-2 px-2 py-1 bg-gray-400 text-white rounded"
                      onClick={() => setEditingWorkOrderId(null)}
                    >
                      취소
                    </button>
                  </>
                ) : (
                  <button
                    className="px-2 py-1 bg-blue-600 text-white rounded"
                    onClick={() => {
                      setEditingWorkOrderId(it.workOrderId);
                      setSelectedStatus(it.status ?? "");
                    }}
                  >
                    상태 변경
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <ConfirmModal />
    </div>
  );
}