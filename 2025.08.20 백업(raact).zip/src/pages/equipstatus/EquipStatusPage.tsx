import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../../lib/api";
import { toPage } from "../../adapters/page";
import type { PageResponse } from "../../types/api";

// 설비 상태 로그 타입
type EquipStatusItem = {
  logId: number;
  equipmentId: string;
  status: string;
  startTime: string;
  endTime?: string;
};

// 등록용 요청 타입
type EquipStatusRequest = {
  equipmentId: string;
  statusCode: string;
  startTimeUtc: string;
  endTimeUtc?: string | null;
};

export default function EquipStatusPage() {
  const [equipmentId, setEquipmentId] = useState("EQ001"); // 기본값 설정
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [form, setForm] = useState<EquipStatusRequest>({
    equipmentId: "EQ001",
    statusCode: "RUN",
    startTimeUtc: new Date().toISOString(),
    endTimeUtc: null,
  });

  const {
    data,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ["equip-status", equipmentId, from, to],
    queryFn: async () => {
      const params: any = {
        equipmentId,
        page: 0,
        size: 20,
        sort: "startTime,desc",
      };
      if (from) params.from = new Date(from).toISOString();
      if (to) params.to = new Date(to).toISOString();

      const res = await api.get<PageResponse<EquipStatusItem>>("/equip-status", { params });
      return toPage(res.data);
    },
  });

  const handleRegister = async () => {
    try {
      await api.post("/equip-status", form);
      alert("등록 성공");
      refetch(); // 목록 갱신
    } catch (err) {
      alert("등록 실패");
      console.error(err);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">설비 상태 모니터링</h1>

      {/* 🔍 검색 필터 */}
      <div className="grid grid-cols-5 gap-4 items-end mb-6">
        <div>
          <label className="text-sm block mb-1">설비</label>
          <input
            className="w-full border p-1"
            value={equipmentId}
            onChange={(e) => setEquipmentId(e.target.value)}
          />
        </div>
        <div>
          <label className="text-sm block mb-1">From</label>
          <input
            type="datetime-local"
            className="w-full border p-1"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
        </div>
        <div>
          <label className="text-sm block mb-1">To</label>
          <input
            type="datetime-local"
            className="w-full border p-1"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
        </div>
        <div>
          <button onClick={() => refetch()} className="bg-blue-600 text-white px-4 py-2 rounded">
            조회
          </button>
        </div>
      </div>

      {/* 📝 등록 폼 */}
      <div className="bg-gray-50 border p-4 mb-6">
        <h2 className="text-md font-semibold mb-2">RUN 등록</h2>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <label className="text-sm block mb-1">설비</label>
            <input
              className="w-full border p-1"
              value={form.equipmentId}
              onChange={(e) => setForm({ ...form, equipmentId: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm block mb-1">상태</label>
            <select
              className="w-full border p-1"
              value={form.statusCode}
              onChange={(e) => setForm({ ...form, statusCode: e.target.value })}
            >
              <option value="RUN">RUN</option>
              <option value="IDLE">IDLE</option>
              <option value="DOWN">DOWN</option>
            </select>  
          </div>
          <div>
            <label className="text-sm block mb-1">시작시간 (UTC)</label>
            <input
              type="datetime-local"
              className="w-full border p-1"
              value={form.startTimeUtc.slice(0, 16)}
              onChange={(e) => {
                const iso = new Date(e.target.value).toISOString();
                setForm({ ...form, startTimeUtc: iso });
              }}
            />
          </div>
          <div className="flex items-end">
            <button onClick={handleRegister} className="bg-green-600 text-white px-4 py-2 rounded">
              RUN 등록
            </button>
          </div>
        </div>
      </div>

      {/* 📋 테이블 */}
      {isLoading ? (
        <div>로딩 중...</div>
      ) : error ? (
        <div className="text-red-500">에러 발생</div>
      ) : (
        <table className="w-full text-sm border">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-2 border">Log ID</th>
              <th className="p-2 border">설비</th>
              <th className="p-2 border">상태</th>
              <th className="p-2 border">시작시간</th>
              <th className="p-2 border">종료시간</th>
            </tr>
          </thead>
          <tbody>
            {data!.items.map((log) => (
              <tr key={log.logId} className="border-b">
                <td className="p-2 text-center">{log.logId}</td>
                <td className="p-2 text-center">{log.equipmentId}</td>
                <td className="p-2 text-center">{log.status}</td>
                <td className="p-2 text-center">{new Date(log.startTime).toLocaleString()}</td>
                <td className="p-2 text-center">
                  {log.endTime ? new Date(log.endTime).toLocaleString() : "-"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}