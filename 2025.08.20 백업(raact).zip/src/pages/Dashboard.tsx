export default function Dashboard(){
  return <div className="text-xl font-semibold">대시보드</div>;
}