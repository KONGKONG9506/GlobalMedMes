import { useQuery } from "@tanstack/react-query";
import { api } from "../../lib/api";
import { toPage, PageResponse } from "../../adapters/page";

type PerfItem = {
  performanceId: number;
  workOrderId: string; itemId: string; processId: string; equipmentId: string;
  producedQty: number; defectQty: number; startTime: string; endTime: string;
};

export default function PerformancesList(){
  const { data, isLoading, error } = useQuery({
    queryKey: ["performances", 0, 20, "startTime,desc"],
    queryFn: async () => {
      const { data } = await api.get<PageResponse<PerfItem>>(
        "/performances", { params: { page: 0, size: 20, sort: "startTime,desc" } }
      );
      return toPage(data);
    }
  });

  if (isLoading) return <div>로딩...</div>;
  if (error)     return <div>오류</div>;

  return (
    <div>
      <h1 className="text-lg font-semibold mb-3">실적</h1>
      <table className="w-full border">
        <thead><tr className="bg-gray-100">
          <th className="p-2">WO</th><th className="p-2">품목</th><th className="p-2">설비</th>
          <th className="p-2 text-right">생산</th><th className="p-2 text-right">불량</th><th className="p-2">시작</th>
        </tr></thead>
        <tbody>
        {data!.items.map(it => (
          <tr key={it.performanceId} className="border-t">
            <td className="p-2">{it.workOrderId}</td>
            <td className="p-2">{it.itemId}</td>
            <td className="p-2">{it.equipmentId}</td>
            <td className="p-2 text-right">{it.producedQty}</td>
            <td className="p-2 text-right">{it.defectQty}</td>
            <td className="p-2">{new Date(it.startTime).toLocaleString()}</td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  );
}