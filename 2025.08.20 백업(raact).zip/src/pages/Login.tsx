import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useAuthStore } from "../store/auth";
import { useNavigate } from "react-router-dom";
import { isAxiosError } from "axios";

type LoginRes = { token: string; user: { userId: string } };

export default function Login() {
  const [username, setU] = useState("");
  const [password, setP] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const setAuth = useAuthStore((s) => s.setAuth);
  const nav = useNavigate();   

  useEffect(() => {
    const savedId = localStorage.getItem("rememberedId");
    if (savedId) {
      setU(savedId);
      setRememberMe(true);
    }
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data } = await api.post<LoginRes>("/auth/login", { username, password });
      setAuth(data.token, data.user.userId);
      if (rememberMe) {
        localStorage.setItem("rememberedId", username);
      } else {
        localStorage.removeItem("rememberedId");
      }
      nav("/");
    } catch (err: unknown) {
      let msg = "로그인 실패";
      if (isAxiosError(err)) {
        msg = err.response?.data?.message ?? msg;
      } else if (err instanceof Error) {
        msg = err.message;
      }
      alert(msg);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={submit} className="w-80 border rounded p-4 space-y-3">
        <div className="text-lg font-bold">로그인</div>
        <input
          className="w-full border px-2 py-1"
          placeholder="아이디"
          value={username}
          onChange={(e) => setU(e.target.value)}
        />
        <input
          className="w-full border px-2 py-1"
          type="password"
          placeholder="비밀번호"
          value={password}
          onChange={(e) => setP(e.target.value)}
        />

        <label className="flex items-center text-sm space-x-2">
          <input
            type="checkbox"
            checked={rememberMe}
            onChange={(e) => setRememberMe(e.target.checked)}
          />
          <span>ID 기억하기</span>
        </label>

        <button className="w-full bg-black text-white py-2 rounded">로그인</button>
      </form>
    </div>
  );
}
